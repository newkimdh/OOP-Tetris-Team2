#pragma once
#include "Common.h"

namespace Tetris {
    // 1. �߻� Ŭ���� �ڽĿ��� override�� ����� �Ѵ�.
    class BlockBase {
    public:
        int x, y;
        int angle;

        BlockBase();
        virtual ~BlockBase() = default;

        virtual int getType() const = 0;
        /*virtual void draw(bool erase = false) const = 0;*/
        virtual void draw(bool erase = false, bool isGhost = false) const = 0; // �Ķ���� �߰�

        int getNextAngle() const;
    };

    // 2. ��ü Ŭ����
    class ShapeBlock : public BlockBase {
    private:
        int type;

    public:
        ShapeBlock();
        void spawn(int newType);

        int getType() const override;
       /* void draw(bool erase = false) const override;*/
        void draw(bool erase = false, bool isGhost = false) const override; // �Ķ���� �߰�
    };
}
#include "Game.h"

int main() {
    Tetris::Game game;
    game.run();
    return 0;
}